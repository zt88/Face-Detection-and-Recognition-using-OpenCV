#include <iostream>
#include <opencv.hpp>
#include <face.hpp>
#include <fstream>


using namespace std;
using namespace cv;
using namespace cv::face;

string lbp_face_datapath = "lbpcascade_frontalface_improved.xml"; //The address of LBP detector

int main()
{
    string filename = string("pic/path.txt");
    ifstream file(filename.c_str(), ifstream::in);

    if(!file)
    {
        cout << "could not load the file." << endl;
    }

    vector <Mat> images;
    vector <int> labels;// Define two vectors to store images and label of person

    char separator = ';';
    string line, path, classlabel;

    //import images
    while (getline(file, line))
    {
        stringstream lines(line);
        getline(lines, path, separator);
        getline(lines, classlabel);
        images.push_back(imread(path, 0));
        labels.push_back(atoi(classlabel.c_str()));
    }

    //Show height and width of images
    int height = images[1].rows;
    int width = images[1].cols;
    cout << "height: " << height << " width: " << width << endl; // All the images are in the same size, just show one image's

    //Do a test to verify the accuracy of template
    //Test parameters
    Mat testSample = images[images.size()-1]; //Choose the last photo as the sample
    int testLabel = labels[labels.size()-1];
    images.pop_back();
    labels.pop_back();

    //Create EigenFace Model as template
    Ptr<BasicFaceRecognizer> model = EigenFaceRecognizer::create();
    model-> train(images, labels);

    //Test the accuracy
    int predictedLabel = model -> predict(testSample);
    cout << "actual label: " << testLabel << " predict label: " << predictedLabel << endl;

    CascadeClassifier faceDetector;
    faceDetector.load(lbp_face_datapath); // Load the detector

    VideoCapture capture;
	capture.open("121.avi");// Run the video

    if (!capture.isOpened())
	{
		printf("can't open video\n");
		return -1;
	}

	Mat frame;
	namedWindow("face_recognition", WINDOW_AUTOSIZE);

	vector <Rect> faces;// To store detected faces
	Mat dst;// intermediate carrier

	while (capture.read(frame))
    {
        faceDetector.detectMultiScale(frame, faces, 1.1, 3, 0, Size(100, 100), Size(1200, 1200)); //Detect faces

        for (int i = 0; i < faces.size(); i++)
        {
            Mat roi = frame(faces[i]);
            cvtColor(roi, dst, COLOR_BGR2GRAY);// convert frames to gray images to match the template

            resize(dst, testSample, testSample.size()); // resize the frames as same as test sample size and transport the dst images to the test sample

            int label = model -> predict(testSample);// Recognize faces to find the corresponding label

            rectangle(frame, faces[i], Scalar(0, 0, 260), 2, 8, 0);// draw a rectangle on the face

            if(label == 1)
            {
                string name = "Jerry";
                putText(frame, name, Point(faces[1].x, faces[1].y), FONT_HERSHEY_COMPLEX, 1, Scalar(260, 0, 0), 2, 8);// print name
            }
            if (faces.size() > 1)
            {
                string name2 = "Unknown";
                putText(frame, name2, Point(faces[0].x, faces[0].y), FONT_HERSHEY_COMPLEX, 1, Scalar(260, 0, 0), 2, 8);
            }
        }

            imshow("face_recognition", frame);

        if (waitKey(1) == 27)
        {
            break;
        } // Click ESC to quit


    }

    waitKey(0);
    return 0;
}
