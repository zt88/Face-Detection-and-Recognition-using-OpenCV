#include <iostream>
#include <opencv.hpp>
#include <face.hpp>
#include <fstream>


using namespace std;
using namespace cv;
using namespace cv::face;
char* win_title = new char[128];


int main()
{
    string filename = string("pic/path.txt");
    ifstream file(filename.c_str(), ifstream::in);
    if(!file)
    {
        cout << "could not load the file." << endl;
    }

    vector <Mat> images;
    vector <int> labels;

    char separator = ';';
    string line, path, classlabel;

    //read images
    while (getline(file, line))
    {
        stringstream lines(line);
        getline(lines, path, separator);
        getline(lines, classlabel);
        images.push_back(imread(path, 0));
        labels.push_back(atoi(classlabel.c_str()));
    }

    int height = images[1].rows;
    int width = images[1].cols;
    cout << "height: " << height << " width: " << width << endl;

    //Test parameters
//    Mat testSample = images[images.size()-1];
//    int testLabel = labels[labels.size()-1];
//    images.pop_back();
//    labels.pop_back();


    //Create EigenFace Model
    Ptr<BasicFaceRecognizer> model = EigenFaceRecognizer::create();
    model-> train(images, labels);

    //Recognition face
//    int predictedLabel = model -> predict(testSample);
//    cout << "actual label: " << testLabel << " predict label: " << predictedLabel << endl;


    //Calculate eigenvalue & eigenvector
    Mat vals = model -> getEigenValues();
    cout << vals.rows << "  " << vals.cols << endl;

    Mat vecs = model -> getEigenVectors();
    cout << vecs.rows << "  " << vecs.cols << endl;

    Mat mean = model -> getMean();
    cout << mean.rows << "  " << mean.cols << endl;

    //Display the Mean face
    Mat meanface = mean.reshape(1, height);
    Mat dst;

    if (meanface.channels()== 1)
    {
        normalize(meanface, dst, 0, 255, NORM_MINMAX, CV_8UC1);
    }
    else if (meanface.channels()== 3)
    {
        normalize(meanface, dst, 0, 255, NORM_MINMAX, CV_8UC3);
    }

    imshow("Mean Face", dst);

    //Display EigenFace
    for(int i = 0; i < min(10, vecs.cols); i++)
    {
        Mat feature_vec = vecs.col(i).clone();
        Mat grayscale;
        Mat feature_face = feature_vec.reshape(1, height);

        if (feature_face.channels()== 1)
    {
        normalize(feature_face, grayscale, 0, 255, NORM_MINMAX, CV_8UC1);
    }
        else if (feature_face.channels()== 3)
    {
        normalize(feature_face, grayscale, 0, 255, NORM_MINMAX, CV_8UC3);
    }

        Mat colorface;
        applyColorMap(grayscale, colorface, COLORMAP_BONE);
        sprintf(win_title, "EigenFace_%d", i);

        imshow(win_title, colorface);
    }

    //Rebuild face
    for (int num = min(10, vecs.cols); num < min(300, vecs.cols); num+=15)
    {
        Mat vecs_space = Mat(vecs, Range::all(), Range(0, num));
        Mat projection = LDA::subspaceProject(vecs_space, mean, images[0].reshape(1, 1));
        Mat reconstruction = LDA::subspaceReconstruct(vecs_space, mean, projection);

        Mat result = reconstruction.reshape(1, height);

        if (result.channels()== 1)
    {
        normalize(result, reconstruction, 0, 255, NORM_MINMAX, CV_8UC1);
    }
    else if (result.channels()== 3)
    {
        normalize(result, reconstruction, 0, 255, NORM_MINMAX, CV_8UC3);
    }

        sprintf(win_title, "rebuild face %d", num);
        imshow(win_title, reconstruction);
    }

    waitKey(0);
    return 0;
}
